/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto;

import javax.swing.JOptionPane;

/**
 *
 * @author Usuario
 */
public class Proyecto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
  
        System.out.println("*Clinica Integral VITALIS* \nPor favor ingrese sus datos para el registro");
        
        String nombre = JOptionPane.showInputDialog("Digite su nombre:");
        System.out.println("Su nombre es: " + nombre);
          
        String apellido1 = JOptionPane.showInputDialog("Digite su primer apellido");
        System.out.println("Sus primer apellido es: " + apellido1);
        
        String apellido2 = JOptionPane.showInputDialog("Digite su segundo apellido");
        System.out.println("Sus segundo apellido es: " + apellido2);
          
        String cedula = JOptionPane.showInputDialog("Digite su cedula");
        System.out.println("Su cedula es: " + cedula);
        
        String fechaNacimiento = JOptionPane.showInputDialog("Ingrese su fecha de nacimiento");
        System.out.println("Su fecha de nacimiento es: " + fechaNacimiento);
        
        String telefono = JOptionPane.showInputDialog("Digite su telefono");
        System.out.println("Su telefono es: " + telefono);
        
        String correo = JOptionPane.showInputDialog("Digite su correo");
        System.out.println("Su correo es: " + correo);
        
        String historiaClinica = JOptionPane.showInputDialog("¿Padece alguna enfermedad crónica? (Escriba N/A si está sano):");
        System.out.println("Su historia Clina es: " + historiaClinica);
        
        System.out.println("-----------------------------");
        System.out.println("*Usuario agregado con exito*");
        System.out.println("-----------------------------");
        boolean confirmacionDatos = false;

        while (!confirmacionDatos) {
        String resumen = "Por favor confirme sus datos:\n\n"
            + "Nombre: " + nombre + "\n"
            + "Primer Apellido: " + apellido1 + "\n"
            + "Segundo Apellido: " + apellido2 + "\n"
            + "Cédula: " + cedula + "\n"
            + "Fecha de Nacimiento: " + fechaNacimiento + "\n"
            + "Teléfono: " + telefono + "\n"
            + "Correo: " + correo + "\n"
            + "Historia Clínica: " + historiaClinica + "\n\n"
            + "¿Los datos ingresados son correctos?";

         int opcion = JOptionPane.showOptionDialog(null, resumen, "Confirmación de Datos",
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null,
            new Object[]{"Sí, es correcta", "Editar"}, "Sí, es correcta");

        if (opcion == 0) {
        confirmacionDatos = true;
        JOptionPane.showMessageDialog(null, "¡Usuario agregado con éxito!");
        System.out.println("-----------------------------");
        System.out.println("*Usuario agregado con éxito*");
        System.out.println("-----------------------------");
    }   else {
        nombre = JOptionPane.showInputDialog("Digite su nombre:");
        apellido1 = JOptionPane.showInputDialog("Digite su primer apellido:");
        apellido2 = JOptionPane.showInputDialog("Digite su segundo apellido:");
        cedula = JOptionPane.showInputDialog("Digite su cédula:");
        fechaNacimiento = JOptionPane.showInputDialog("Ingrese su fecha de nacimiento:");
        telefono = JOptionPane.showInputDialog("Digite su teléfono:");
        correo = JOptionPane.showInputDialog("Digite su correo electrónico:");
        historiaClinica = JOptionPane.showInputDialog("¿Padece alguna enfermedad crónica? (Escriba N/A si está sano):");
    }
}
    }
    
}
