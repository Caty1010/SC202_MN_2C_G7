/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectoclasecita;

/**
 *
 * @author Marian
 */
public class ProyectoClaseCita {

    public static void main(String[] args) {
     //ejemplo de paciente
     Paciente paciente = new Paciente("Marian", "Lara", "Lara", "123456", "01/01/2000", "8888-88888", "marian@gmail.com", "N/A");
             
     //método de prueba 
     ClaseMedico medico = new ClaseMedico("Dr.X", "CR123", "dra@vitalis", "22222-2222", "Psicología", new String[]{"Lunes", "Miércoles"}, new String[]{"09:00 AM", "02:00 PM"});
             
     //crear cita
     Cita cita= new Cita(1, "22/07/2025", "02:00PM", paciente, medico);
    
     //cita
     cita.mostrarDatosCita();
    }
}
