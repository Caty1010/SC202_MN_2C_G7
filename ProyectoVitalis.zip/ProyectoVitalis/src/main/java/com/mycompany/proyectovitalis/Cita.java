/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectovitalis;

import javax.swing.JOptionPane;

/**
 *
 * @author Grupo 7
 */
public class Cita {
    //atributos 
    private int idCita;
    private String fecha;
    private String hora;
    private Paciente paciente;
    private ClaseMedico medico;
    
    //contructor
    
    public Cita (int idCita, String fecha, String hora, Paciente paciente, ClaseMedico medico){
        this.idCita = idCita;
        this.fecha = fecha;
        this.hora = hora;
        this.paciente = paciente;
        this.medico = medico;
    }
    
    public int getidCita() {
        return idCita;
    }
    public void setIdCita(int idCita) {
        this.idCita = idCita;
    }
    public String getFecha(){
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public String getHora (){
        return hora;
    }
    public void setHora(String hora){
        this.hora = hora;
    }
    public Paciente getPaciente(){
    return paciente;
    }
    public void setPaciente (Paciente paciente){
        this.paciente = paciente;
    }
    public ClaseMedico getMedico (){
        return medico;
    }
    public void setMedico(ClaseMedico medico) {
        this.medico = medico;
    }
    
    // Impresiones
    public void mostrarDatosCita() {
    String mensaje = 
        "Detalles de su cita:\n" +
        "ID de cita: " + idCita + "\n" +
        "Fecha: " + fecha + "\n" +
        "Hora: " + hora + "\n" +
        "Paciente: " + paciente.getNombre() + "\n" +
        "Cédula: " + paciente.getCedula() + "\n" +
        "Médico: " + medico.getNombre() + "\n" +
        "Especialidad: " + medico.getEspecialidad();

    JOptionPane.showMessageDialog(null, mensaje, "Resumen de la Cita", JOptionPane.INFORMATION_MESSAGE);
}
}
