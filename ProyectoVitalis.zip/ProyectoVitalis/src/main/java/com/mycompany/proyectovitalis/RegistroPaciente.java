/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectovitalis;

import javax.swing.JOptionPane;

/**
 *
 * @author Grupo 7
 */
public class RegistroPaciente {
    public static Paciente registrarPaciente() {
        String nombre = JOptionPane.showInputDialog("Digite el nombre:");
        String apellido1 = JOptionPane.showInputDialog("Digite el primer apellido");
        String apellido2 = JOptionPane.showInputDialog("Digite el segundo apellido");
        String cedula = JOptionPane.showInputDialog("Digite la cedula");
        String fechaNacimiento = JOptionPane.showInputDialog("Ingrese la fecha de nacimiento");
        String telefono = JOptionPane.showInputDialog("Digite el telefono");
        String correo = JOptionPane.showInputDialog("Digite el correo");
        String historiaClinica = JOptionPane.showInputDialog("¿Padece alguna enfermedad crónica? (Escriba N/A si está sano):");

        boolean confirmacionDatos = false;

        while (!confirmacionDatos) {
            String resumen = "Por favor confirme sus datos:\n\n"
                + "Nombre: " + nombre + "\n"
                + "Primer Apellido: " + apellido1 + "\n"
                + "Segundo Apellido: " + apellido2 + "\n"
                + "Cédula: " + cedula + "\n"
                + "Fecha de Nacimiento: " + fechaNacimiento + "\n"
                + "Teléfono: " + telefono + "\n"
                + "Correo: " + correo + "\n"
                + "Historia Clínica: " + historiaClinica + "\n\n"
                + "¿Los datos ingresados son correctos?";

            int opcion = JOptionPane.showOptionDialog(null, resumen, "Confirmación de Datos",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null,
                new Object[]{"Sí, es correcta", "Editar"}, "Sí, es correcta");

            if (opcion == 0) {
                confirmacionDatos = true;
                JOptionPane.showMessageDialog(null, "¡Usuario agregado con éxito!");
            } else {
                nombre = JOptionPane.showInputDialog("Digite su nombre:");
                apellido1 = JOptionPane.showInputDialog("Digite su primer apellido:");
                apellido2 = JOptionPane.showInputDialog("Digite su segundo apellido:");
                cedula = JOptionPane.showInputDialog("Digite su cédula:");
                fechaNacimiento = JOptionPane.showInputDialog("Ingrese su fecha de nacimiento:");
                telefono = JOptionPane.showInputDialog("Digite su teléfono:");
                correo = JOptionPane.showInputDialog("Digite su correo electrónico:");
                historiaClinica = JOptionPane.showInputDialog("¿Padece alguna enfermedad crónica? (Escriba N/A si está sano):");
            }
        }

        return new Paciente(nombre, apellido1, apellido2, cedula, fechaNacimiento, telefono, correo, historiaClinica);
    }
}
