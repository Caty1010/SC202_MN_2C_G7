/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectovitalis;

import javax.swing.JOptionPane;

/**
 *
 * @author Grupo 7
 */
public class ProyectoVitalis {

    public static void main(String[] args) {
        Paciente paciente = null;
        Cita cita = null;

        ClaseMedico[] medicos = {
            new ClaseMedico("Dra. Gabriela Arroyo", "CR00234", "gabriela@vitalis.com", "2223-2004", "Psicologia",
                    new String[]{"Lunes", "Miércoles"}, new String[]{"9:00 AM", "12:00 PM"}),
            new ClaseMedico("Dr. Luis Jimenez", "CR00765", "luis@vitalis.com", "2223-2005", "Nutricion",
                    new String[]{"Martes", "Viernes"}, new String[]{"1:00 PM", "4:00 PM"}),
            new ClaseMedico("Dra. Viviana Torres", "CR00954", "viviana@vitalis.com", "2223-2006", "Fisioterapia",
                    new String[]{"Viernes", "Sábado"}, new String[]{"11:00 AM", "12:00 PM"}),
            new ClaseMedico("Dra. Rachell Chavarria", "CR00523", "rachell@vitalis.com", "2223-2008", "Dermatologia",
                    new String[]{"Martes", "Viernes"}, new String[]{"9:30 AM", "11:30 AM"}),
        };

        int opcion;
        do {
            String menuTexto = "Bienvenido/a al sistema de citas de la Clínica Integral VITALIS\n\n"
                    + "Seleccione una opción:\n"
                    + "1. Agendar una cita\n"
                    + "2. Ver especialidades disponibles\n"
                    + "3. Ver información de los médicos\n"
                    + "4. Ver resumen de la cita agendada\n"
                    + "5. Salir del sistema";

            String opcionStr = JOptionPane.showInputDialog(menuTexto);
            if (opcionStr == null) break;
            opcion = Integer.parseInt(opcionStr);

            switch (opcion) {
                case 1:
                    paciente = RegistroPaciente.registrarPaciente();

                    String especialidades = "Estas son las especialidades disponibles:\n"
                            + "1. Psicologia\n"
                            + "2. Nutricion\n"
                            + "3. Fisioterapia\n"
                            + "4. Dermatologia\n\n"
                            + "¿Cuál especialidad desea para la cita? (Digite el número correspondiente)";
                    String seleccion = JOptionPane.showInputDialog(especialidades);

                    int seleccionEspecialidad = Integer.parseInt(seleccion);
                    ClaseMedico medicoSeleccionado = null;
                    if (seleccionEspecialidad >= 1 && seleccionEspecialidad <= 4) {
                        medicoSeleccionado = medicos[seleccionEspecialidad - 1];
                    }

                    if (medicoSeleccionado == null) {
                        JOptionPane.showMessageDialog(null, "Especialidad no encontrada.");
                    } else {
                        String fechaCita = JOptionPane.showInputDialog("Ingrese la fecha de la cita:");
                        String horaCita = JOptionPane.showInputDialog("Ingrese la hora de la cita:");
                        int id = (int) (Math.random() * 1000);
                        cita = new Cita(id, fechaCita, horaCita, paciente, medicoSeleccionado);
                        JOptionPane.showMessageDialog(null, "¡Cita agendada con éxito!");
                        cita.mostrarDatosCita();
                    }
                    break;

                case 2:
                    String mensaje = "Especialidades disponibles:\n";
                    for (ClaseMedico medico : medicos) {
                        mensaje += "- " + medico.getEspecialidad() + "\n";
                    }
                    JOptionPane.showMessageDialog(null, mensaje);
                    break;

                case 3:
                    String info = "Información de los médicos:\n";
                    for (ClaseMedico medico : medicos) {
                        info += "Nombre: " + medico.getNombre() + "\n";
                        info += "Especialidad: " + medico.getEspecialidad() + "\n";
                        info += "Correo: " + medico.getCorreo() + "\n";
                        info += "Teléfono: " + medico.getTelefono() + "\n";
                        info += "Días disponibles: " + String.join(", ", medico.getDiasDisponibles()) + "\n";
                        info += "Horas disponibles: " + String.join(", ", medico.getHorasDisponibles()) + "\n\n";
                    }
                    JOptionPane.showMessageDialog(null, info);
                    break;

                case 4:
                    if (cita != null) {
                        cita.mostrarDatosCita();
                    } else {
                        JOptionPane.showMessageDialog(null, "No hay ninguna cita agendada actualmente.");
                    }
                    break;

                case 5:
                    JOptionPane.showMessageDialog(null, "Gracias por utilizar el sistema de la Clínica Vitalis.");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Intente de nuevo.");
                    break;
            }
        } while (opcion != 5);
    }
}
