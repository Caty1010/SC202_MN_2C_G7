/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectovitalis;

import javax.swing.JOptionPane;

/**
 *
 * @author katal
 */
public class ClaseMedico {
// ATRIBUTOS
    private String nombre;
    private String codigo;
    private String correo;
    private String telefono;
    private String especialidad;
    private String[] diasDisponibles;
    private String[] horasDisponibles;

    // CONSTRUCTOR
    public ClaseMedico(String nombre, String codigo, String correo, String telefono, String especialidad,
                       String[] diasDisponibles, String[] horasDisponibles) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.correo = correo;
        this.telefono = telefono;
        this.especialidad = especialidad;
        this.diasDisponibles = diasDisponibles;
        this.horasDisponibles = horasDisponibles;
    }

    // MÉTODOS
    public void mostrarMedico() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Código CMC: " + codigo);
        System.out.println("Correo: " + correo);
        System.out.println("Teléfono: " + telefono);
        System.out.println("Especialidad: " + especialidad);
    }

    public void mostrarDiasPorEspecialidad() {
        System.out.println("Días disponibles: ");
        for (String dia : diasDisponibles) {
            System.out.println("- " + dia);
        }
    }

    public void mostrarHoraPorEspecialidad() {
        System.out.println("Horarios disponibles: ");
        for (String hora : horasDisponibles) {
            System.out.println("- " + hora);
        }
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public String getNombre() {
        return nombre;
    }
 
    public String getCorreo() {
        return correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public String[] getDiasDisponibles() {
        return diasDisponibles;
    }

    public String[] getHorasDisponibles() {
        return horasDisponibles;
}
}