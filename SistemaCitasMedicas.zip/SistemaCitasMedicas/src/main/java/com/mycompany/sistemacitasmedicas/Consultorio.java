/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemacitasmedicas;

/**
 * @author Grupo 7
 */
class Consultorio {
    Paciente[] listaPacientes = new Paciente[10];
    Medico[] listaMedicos = new Medico[5];
    Cita[] listaCitas = new Cita[20];
//falta crear las clases
    int contadorPacientes = 0;
    int contadorMedicos = 0;
    int contadorCitas = 0;

    public void registrarPaciente(String nombre, String cedula, String telefono) {
        if (contadorPacientes < listaPacientes.length) {
            Paciente nuevo = new Paciente(nombre, cedula, telefono);
            listaPacientes[contadorPacientes] = nuevo;
            contadorPacientes++;
        }
    }

    public void agendarCita() {
        // Aquí se agregará la lógica cuando todo este
        System.out.println("Función agendarCita aún no implementada.");
    }

    public void modificarCita() {
        System.out.println("Función modificarCita aún no implementada.");
    }

    public void eliminarCita() {
        System.out.println("Función eliminarCita aún no implementada.");
    }

    public void generarReporteDiario() {
        System.out.println("Función generarReporteDiario aún no implementada.");
    }
}
