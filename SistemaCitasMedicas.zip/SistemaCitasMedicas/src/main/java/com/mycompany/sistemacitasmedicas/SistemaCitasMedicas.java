/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemacitasmedicas;

import javax.swing.JOptionPane;

/**
 *
 * @author Grupo 7
 */
public class SistemaCitasMedicas {

    public static void main(String[] args) {
        Consultorio consultorio = new Consultorio();
        int opcion;
 //Cuando todo este incluido se cambiara el menu 
        do {
            String menu = """
                MENÚ PRINCIPAL
                1. Registrar paciente
                2. Salir
                """;
            opcion = Integer.parseInt(JOptionPane.showInputDialog(menu));

            switch (opcion) {
                case 1 -> {
                    String nombre = JOptionPane.showInputDialog("Ingrese el nombre del paciente:");
                    String cedula = JOptionPane.showInputDialog("Ingrese la cédula del paciente:");
                    String telefono = JOptionPane.showInputDialog("Ingrese el teléfono del paciente:");
                    
                    consultorio.registrarPaciente(nombre, cedula, telefono);
                    JOptionPane.showMessageDialog(null, "Paciente registrado con éxito.");
                }
                case 2 -> JOptionPane.showMessageDialog(null, "Gracias por usar el sistema.");
                default -> JOptionPane.showMessageDialog(null, "Opción no válida.");
            }
        } while (opcion != 2);
    }
}
